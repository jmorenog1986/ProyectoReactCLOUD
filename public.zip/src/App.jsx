import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import { Button } from './componets/ui/Button'
import { UsersPage } from './componets/pages/UsersPage'

function App() {
  const [count, setCount] = useState(0)
  const [users, setUsers] = useState([]);//agregar



  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">

        <Button variant="secondary" size="md" onClick={() => alert("Locos todos! ")}>
          Alert
        </Button>

        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>

        <UsersPage></UsersPage>

  
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export default App
